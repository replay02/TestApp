package com.kt.weatherprovidercaller;


import java.io.Serializable;

public class WeatherData implements Serializable{

    private String stationName;
    private String dmX;
    private String dmY;


    public String getStationName() {
        return stationName;
    }

    public void setStationName(String stationName) {
        this.stationName = stationName;
    }

    public String getDmX() {
        return dmX;
    }

    public void setDmX(String dmX) {
        this.dmX = dmX;
    }

    public String getDmY() {
        return dmY;
    }

    public void setDmY(String dmY) {
        this.dmY = dmY;
    }
}
