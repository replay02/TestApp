package com.kt.weatherprovidercaller;

import android.content.ContentResolver;
import android.database.ContentObserver;
import android.database.Cursor;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.DividerItemDecoration;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.View;
import android.widget.Button;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {
    private ArrayList<WeatherData> data = new ArrayList<>();
    AdapterWeatherList adapter;

//    String URL = "content://com.kt.testapp.MyContentProvider/weather_location/광진구";
    String URL = "content://com.kt.testapp.MyContentProvider/weather_location";

    ContentResolver contentResolver;

    @Override
    protected void onResume() {
        super.onResume();
        try {
            contentResolver.registerContentObserver(Uri.parse(URL),true,contentObserver);
            findViewById(R.id.text).setVisibility(View.GONE);
            findViewById(R.id.btn).setVisibility(View.VISIBLE);
        }
        catch (Exception e) {
            findViewById(R.id.text).setVisibility(View.VISIBLE);
            findViewById(R.id.btn).setVisibility(View.GONE);
        }
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        contentResolver = getContentResolver();
        //데이터베이스의 변경을 알리는 신호를 감시하는 옵져버를 등록합니다. 메모리 누수가 있을수 있으니 사용후 unregisterContentObserver 메소드를 호출해주어야 합니다,

        Button btn = findViewById(R.id.btn);
        btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                setData();
            }
        });

        // 리스트뷰 형태 RecyclerView set
        RecyclerView recyclerView = findViewById(R.id.rvWeather);
        recyclerView.setLayoutManager(new LinearLayoutManager(this, LinearLayoutManager.VERTICAL, false));

        // 구분선 추가
        DividerItemDecoration dividerItemDecoration =
                new DividerItemDecoration(this, new LinearLayoutManager(this).getOrientation());
        recyclerView.addItemDecoration(dividerItemDecoration);

        // adapter set
        adapter = new AdapterWeatherList(this, data);
        recyclerView.setAdapter(adapter);


    }


    private void setData() {
        Cursor c = contentResolver.query(Uri.parse(URL), null, null, null, null);

        data.clear();
        while (c.moveToNext()) {
            WeatherData d = new WeatherData();
            d.setDmX(c.getString(c.getColumnIndex("lat")));
            d.setDmY(c.getString(c.getColumnIndex("lon")));
            d.setStationName(c.getString(c.getColumnIndex("station_name")));
            data.add(d);
        }
        adapter.notifyDataSetChanged();
    }



    ContentObserver contentObserver = new ContentObserver(new Handler()) {
        @Override
        public boolean deliverSelfNotifications() {
            return super.deliverSelfNotifications();
        }

        @Override
        public void onChange(boolean selfChange) {
            super.onChange(selfChange);

            Log.e("TAG","selfChange : " + selfChange);

        }

        @Override
        public void onChange(boolean selfChange, Uri uri) {
            super.onChange(selfChange, uri);
            Log.e("TAG","change : " + uri.getLastPathSegment());
            Log.e("TAG","selfChange : " + selfChange);

            setData();
        }
    };


    @Override
    protected void onDestroy() {
        super.onDestroy();
        contentResolver.unregisterContentObserver(contentObserver);
    }
}
